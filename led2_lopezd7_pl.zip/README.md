# Group Members:

* Dylan Le (led2)
* Dimitri Lopez (lopezd7)

## Running the Code
See `run.sh`.

## Additional Notes:

No additional notes implementation is as described in the PDF.
